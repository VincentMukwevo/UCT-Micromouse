import json
import math

# Milestone 2 parameters: Navigate a random perfect maze to the center
MAP = "random"
TIME_LIMIT = 90.0
IMBALANCE = 0.08
SLIP = 0.08
SEED = 42

def evaluate_run(trajectory_file):
    try:
        with open(trajectory_file, "r") as f:
            data = json.load(f)
    except Exception as e:
        return 0.0, f"Error reading trajectory file: {e}"

    start_x = data.get("start_x", 0.10)
    start_y = data.get("start_y", 0.10)
    final_x = data.get("final_x", start_x)
    final_y = data.get("final_y", start_y)
    sim_time = data.get("time", 0.0)
    crashed = data.get("crashed", False)

    # Center of the 10x10 grid maze (each cell is 0.2m x 0.2m)
    # The center is in cells (4,4), (4,5), (5,4), (5,5) which span x/y in [0.8m, 1.2m]
    target_x = 1.0
    target_y = 1.0
    
    # Calculate distance to center
    dist_to_center = math.hypot(final_x - target_x, final_y - target_y)
    
    feedback = []
    feedback.append("=== Milestone 2 Evaluation Results ===")
    feedback.append(f"Start Position      : ({start_x:.4f}, {start_y:.4f})")
    feedback.append(f"Final Position      : ({final_x:.4f}, {final_y:.4f})")
    feedback.append(f"Final Dist to Center: {dist_to_center:.4f} m")
    feedback.append(f"Simulation Time     : {sim_time:.2f} s")
    
    # Reaching target threshold (within 0.25 meters of the maze center point (1.0, 1.0))
    success_threshold = 0.25
    
    if dist_to_center <= success_threshold:
        grade = 100.0
        feedback.append("SUCCESS: Mouse successfully reached the center of the maze!")
    else:
        # Distance-based grading curve (from starting distance to the center)
        start_dist_to_center = math.hypot(start_x - target_x, start_y - target_y)
        # Score scales based on how much distance the mouse closed toward the center
        closed_ratio = (start_dist_to_center - dist_to_center) / start_dist_to_center
        closed_ratio = max(0.0, min(1.0, closed_ratio))
        grade = closed_ratio * 80.0 # Max 80% if center not fully reached
        
        feedback.append(f"FAILED: Mouse did not reach the center. Closed {closed_ratio*100:.1f}% of starting distance.")

    feedback.append(f"Base navigation score: {grade:.2f}%")

    # Penalties
    penalty = 0.0
    if crashed:
        penalty += 15.0
        feedback.append("[Evaluation] Applied collision penalty: -15%")
        
    if sim_time >= TIME_LIMIT:
        penalty += 10.0
        feedback.append("[Evaluation] Applied timeout penalty: -10%")

    final_grade = max(0.0, grade - penalty)
    final_grade_rounded = round(final_grade)
    feedback.append(f"GRADE: {final_grade_rounded}%")

    return float(final_grade_rounded), "\n".join(feedback)
